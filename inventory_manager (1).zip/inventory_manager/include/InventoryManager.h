#pragma once

/*
 * InventoryManager.h  –  declaration of the C++ UI class
 *
 * This class owns the interactive menu loop.
 * It calls the C backend functions declared in inventory.h.
 */

class InventoryManager {
public:
    /* Entry point – runs the menu loop until the user exits. */
    void run();

private:
    /* Banner & menu rendering */
    void print_banner() const;
    void print_menu()   const;

    /* CRUD handlers */
    void do_add();
    void do_view();
    void do_update();
    void do_delete();
    void do_list();
};
