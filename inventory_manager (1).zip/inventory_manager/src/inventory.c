/*
 * inventory.c  –  C data layer
 *
 * Storage layout: fixed-size records, one per slot.
 * Slot index  =  (id - 1)  so ID 1 lives at offset 0.
 * We allow IDs from 1 … INT_MAX; the file grows on demand.
 */

#include "inventory.h"

#include <stdio.h>
#include <string.h>

/* ── helpers ──────────────────────────────────────────────────── */

/* Byte offset of the record for a given id (id >= 1). */
static long record_offset(int id)
{
    return (long)(id - 1) * (long)sizeof(Item);
}

/* Open the DB file; returns NULL on failure. */
static FILE *open_db(const char *mode)
{
    return fopen(DB_FILE, mode);
}

/* ── public API ───────────────────────────────────────────────── */

/*
 * add_item – append a new record (reject duplicate / deleted slot re-use).
 * We store the item at slot (item->id - 1).
 * Returns 1 on success, 0 on failure.
 */
int add_item(const Item *item)
{
    if (!item || item->id <= 0) return 0;

    /* Check for duplicate: open for reading first. */
    FILE *f = open_db("rb");
    if (f) {
        Item existing;
        if (fseek(f, record_offset(item->id), SEEK_SET) == 0 &&
            fread(&existing, sizeof(Item), 1, f) == 1 &&
            !existing.is_deleted) {
            fclose(f);
            return 0; /* duplicate active id */
        }
        fclose(f);
    }

    /*
     * Open for "r+b" if the file already exists so we can write
     * into an arbitrary offset; otherwise create with "wb".
     */
    f = open_db("r+b");
    if (!f) {
        f = open_db("wb");
        if (!f) return 0;
    }

    if (fseek(f, record_offset(item->id), SEEK_SET) != 0) {
        fclose(f);
        return 0;
    }

    int ok = (fwrite(item, sizeof(Item), 1, f) == 1);
    fclose(f);
    return ok;
}

/*
 * get_item – read one active record by id.
 * Returns 1 on success, 0 if not found / deleted.
 */
int get_item(int id, Item *out)
{
    if (id <= 0 || !out) return 0;

    FILE *f = open_db("rb");
    if (!f) return 0;

    int ok = 0;
    if (fseek(f, record_offset(id), SEEK_SET) == 0 &&
        fread(out, sizeof(Item), 1, f) == 1 &&
        out->id == id &&
        !out->is_deleted) {
        ok = 1;
    }

    fclose(f);
    return ok;
}

/*
 * update_item – overwrite an existing active record.
 * Returns 1 on success, 0 on failure.
 */
int update_item(int id, const Item *updated)
{
    if (id <= 0 || !updated) return 0;

    FILE *f = open_db("r+b");
    if (!f) return 0;

    /* Verify the slot holds an active record with this id. */
    Item existing;
    int ok = 0;
    if (fseek(f, record_offset(id), SEEK_SET) == 0 &&
        fread(&existing, sizeof(Item), 1, f) == 1 &&
        existing.id == id &&
        !existing.is_deleted) {

        /* Rewind to the start of that slot and overwrite. */
        if (fseek(f, record_offset(id), SEEK_SET) == 0) {
            Item to_write = *updated;
            to_write.id  = id;          /* preserve the canonical id */
            to_write.is_deleted = 0;
            ok = (fwrite(&to_write, sizeof(Item), 1, f) == 1);
        }
    }

    fclose(f);
    return ok;
}

/*
 * delete_item – soft-delete: set is_deleted = 1 in place.
 * Returns 1 on success, 0 on failure.
 */
int delete_item(int id)
{
    if (id <= 0) return 0;

    FILE *f = open_db("r+b");
    if (!f) return 0;

    Item existing;
    int ok = 0;
    if (fseek(f, record_offset(id), SEEK_SET) == 0 &&
        fread(&existing, sizeof(Item), 1, f) == 1 &&
        existing.id == id &&
        !existing.is_deleted) {

        existing.is_deleted = 1;
        if (fseek(f, record_offset(id), SEEK_SET) == 0)
            ok = (fwrite(&existing, sizeof(Item), 1, f) == 1);
    }

    fclose(f);
    return ok;
}

/*
 * list_items – scan the whole file; copy active records into buffer.
 * Returns count of items copied (≤ max_items).
 */
int list_items(Item *buffer, int max_items)
{
    if (!buffer || max_items <= 0) return 0;

    FILE *f = open_db("rb");
    if (!f) return 0;

    int count = 0;
    Item tmp;
    while (count < max_items && fread(&tmp, sizeof(Item), 1, f) == 1) {
        if (!tmp.is_deleted)
            buffer[count++] = tmp;
    }

    fclose(f);
    return count;
}
