/*
 * InventoryManager.cpp  –  C++ UI/logic layer
 *
 * Wraps the C backend (inventory.h / inventory.c).
 * Uses std::vector and std::sort as required.
 */

#include "InventoryManager.h"
#include "inventory.h"

#include <algorithm>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <limits>
#include <sstream>
#include <string>
#include <vector>

/* ── ANSI colour codes ────────────────────────────────────────── */
namespace Clr {
    const char* RST  = "\033[0m";
    const char* BOLD = "\033[1m";
    const char* DIM  = "\033[2m";
    const char* RED  = "\033[31m";
    const char* GRN  = "\033[32m";
    const char* YLW  = "\033[33m";
    const char* CYN  = "\033[36m";
    const char* MGT  = "\033[35m";
    const char* BLU  = "\033[34m";
    const char* WHT  = "\033[97m";
}

/* ── tiny helpers ─────────────────────────────────────────────── */

static void clear_stdin()
{
    std::cin.clear();
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
}

/* Validated integer input ≥ min_val. */
static int read_int(const std::string &prompt, int min_val)
{
    int v;
    while (true) {
        std::cout << Clr::CYN << "  ➤ " << Clr::WHT << prompt << Clr::RST;
        if (std::cin >> v && v >= min_val) {
            clear_stdin();
            return v;
        }
        clear_stdin();
        std::cout << Clr::RED << "  ✗  Invalid – must be ≥ " << min_val
                  << ". Try again.\n" << Clr::RST;
    }
}

/* Validated float input ≥ 0. */
static float read_float(const std::string &prompt)
{
    float v;
    while (true) {
        std::cout << Clr::CYN << "  ➤ " << Clr::WHT << prompt << Clr::RST;
        if (std::cin >> v && v >= 0.0f) {
            clear_stdin();
            return v;
        }
        clear_stdin();
        std::cout << Clr::RED << "  ✗  Invalid – must be ≥ 0. Try again.\n"
                  << Clr::RST;
    }
}

/* Validated non-empty string, max NAME_LEN-1 chars. */
static std::string read_name(const std::string &prompt)
{
    std::string s;
    while (true) {
        std::cout << Clr::CYN << "  ➤ " << Clr::WHT << prompt << Clr::RST;
        std::getline(std::cin, s);
        if (!s.empty() && s.size() < NAME_LEN)
            return s;
        std::cout << Clr::RED << "  ✗  Name must be 1–" << (NAME_LEN - 1)
                  << " characters. Try again.\n" << Clr::RST;
    }
}

/* ── pretty print helpers ─────────────────────────────────────── */

static void print_divider(int w = 70)
{
    std::cout << Clr::DIM;
    for (int i = 0; i < w; ++i) std::cout << '-';
    std::cout << Clr::RST << '\n';
}

static void print_item_row(const Item &it)
{
    std::cout << "  "
              << Clr::YLW << std::setw(5)  << it.id        << Clr::RST << "  "
              << Clr::WHT << std::setw(20) << std::left << it.name << std::right << Clr::RST << "  "
              << Clr::GRN << std::setw(8)  << it.quantity   << Clr::RST << "  "
              << Clr::MGT << "$" << std::setw(10) << std::fixed << std::setprecision(2)
                          << it.price      << Clr::RST << '\n';
}

static void print_item_detail(const Item &it)
{
    print_divider();
    std::cout << "  " << Clr::BOLD << Clr::CYN << "Item Detail\n" << Clr::RST;
    print_divider();
    std::cout << "  " << Clr::DIM  << "ID       : " << Clr::RST
              << Clr::YLW  << it.id       << Clr::RST << '\n';
    std::cout << "  " << Clr::DIM  << "Name     : " << Clr::RST
              << Clr::WHT  << it.name     << Clr::RST << '\n';
    std::cout << "  " << Clr::DIM  << "Quantity : " << Clr::RST
              << Clr::GRN  << it.quantity << Clr::RST << '\n';
    std::cout << "  " << Clr::DIM  << "Price    : " << Clr::RST
              << Clr::MGT  << "$" << std::fixed << std::setprecision(2)
                           << it.price    << Clr::RST << '\n';
    print_divider();
}

/* ── InventoryManager ─────────────────────────────────────────── */

void InventoryManager::run()
{
    print_banner();

    while (true) {
        print_menu();
        int choice = read_int("Choose an option (1-6): ", 1);
        std::cout << '\n';

        switch (choice) {
            case 1: do_add();    break;
            case 2: do_view();   break;
            case 3: do_update(); break;
            case 4: do_delete(); break;
            case 5: do_list();   break;
            case 6:
                std::cout << Clr::GRN << "  Goodbye! Data saved to "
                          << DB_FILE << ".\n" << Clr::RST;
                return;
            default:
                std::cout << Clr::RED << "  ✗  Please enter 1–6.\n"
                          << Clr::RST;
        }
        std::cout << '\n';
    }
}

/* ── banner & menu ────────────────────────────────────────────── */

void InventoryManager::print_banner() const
{
    std::cout << '\n'
              << Clr::BOLD << Clr::CYN
              << "  ╔══════════════════════════════════════════╗\n"
              << "  ║       📦  INVENTORY MANAGER  v1.0        ║\n"
              << "  ║     C backend · C++ frontend · STL       ║\n"
              << "  ╚══════════════════════════════════════════╝\n"
              << Clr::RST << '\n';
}

void InventoryManager::print_menu() const
{
    std::cout << Clr::BOLD << Clr::BLU
              << "  ┌─────────────────────────┐\n"
              << "  │        M E N U          │\n"
              << "  ├─────────────────────────┤\n"
              << "  │  1  Add item            │\n"
              << "  │  2  View item by ID     │\n"
              << "  │  3  Update item         │\n"
              << "  │  4  Delete item         │\n"
              << "  │  5  List all items      │\n"
              << "  │  6  Exit                │\n"
              << "  └─────────────────────────┘\n"
              << Clr::RST << '\n';
}

/* ── CRUD operations ──────────────────────────────────────────── */

void InventoryManager::do_add()
{
    std::cout << Clr::BOLD << Clr::GRN << "  [ ADD ITEM ]\n" << Clr::RST;
    print_divider();

    Item it{};
    it.id         = read_int ("ID (positive integer): ", 1);
    std::string nm = read_name("Name: ");
    strncpy(it.name, nm.c_str(), NAME_LEN - 1);
    it.name[NAME_LEN - 1] = '\0';
    it.quantity   = read_int ("Quantity (≥ 0): ", 0);
    it.price      = read_float("Price (≥ 0.00): ");
    it.is_deleted = 0;

    if (add_item(&it))
        std::cout << Clr::GRN << "\n  ✔  Item #" << it.id
                  << " added successfully.\n" << Clr::RST;
    else
        std::cout << Clr::RED << "\n  ✗  Failed – ID #" << it.id
                  << " may already exist.\n" << Clr::RST;
}

void InventoryManager::do_view()
{
    std::cout << Clr::BOLD << Clr::YLW << "  [ VIEW ITEM ]\n" << Clr::RST;

    int id = read_int("Item ID: ", 1);
    Item it{};
    if (get_item(id, &it))
        print_item_detail(it);
    else
        std::cout << Clr::RED << "\n  ✗  Item #" << id
                  << " not found (or deleted).\n" << Clr::RST;
}

void InventoryManager::do_update()
{
    std::cout << Clr::BOLD << Clr::MGT << "  [ UPDATE ITEM ]\n" << Clr::RST;

    int id = read_int("ID to update: ", 1);
    Item existing{};
    if (!get_item(id, &existing)) {
        std::cout << Clr::RED << "\n  ✗  Item #" << id
                  << " not found (or deleted).\n" << Clr::RST;
        return;
    }

    std::cout << Clr::DIM << "  (current: "
              << existing.name << ", qty=" << existing.quantity
              << ", $" << std::fixed << std::setprecision(2) << existing.price
              << ")\n" << Clr::RST;
    print_divider();

    Item updated = existing;
    std::string nm = read_name("New name: ");
    strncpy(updated.name, nm.c_str(), NAME_LEN - 1);
    updated.name[NAME_LEN - 1] = '\0';
    updated.quantity = read_int ("New quantity (≥ 0): ", 0);
    updated.price    = read_float("New price (≥ 0.00): ");

    if (update_item(id, &updated))
        std::cout << Clr::GRN << "\n  ✔  Item #" << id
                  << " updated.\n" << Clr::RST;
    else
        std::cout << Clr::RED << "\n  ✗  Update failed.\n" << Clr::RST;
}

void InventoryManager::do_delete()
{
    std::cout << Clr::BOLD << Clr::RED << "  [ DELETE ITEM ]\n" << Clr::RST;

    int id = read_int("ID to delete: ", 1);

    /* Confirm the item exists before asking for confirmation. */
    Item it{};
    if (!get_item(id, &it)) {
        std::cout << Clr::RED << "\n  ✗  Item #" << id
                  << " not found (or already deleted).\n" << Clr::RST;
        return;
    }

    std::cout << Clr::YLW << "  ⚠  You are about to delete \""
              << it.name << "\" (ID #" << id << ").\n"
              << "  Type 'yes' to confirm: " << Clr::RST;
    std::string confirm;
    std::getline(std::cin, confirm);

    if (confirm != "yes") {
        std::cout << Clr::DIM << "  Cancelled.\n" << Clr::RST;
        return;
    }

    if (delete_item(id))
        std::cout << Clr::GRN << "\n  ✔  Item #" << id
                  << " soft-deleted.\n" << Clr::RST;
    else
        std::cout << Clr::RED << "\n  ✗  Delete failed.\n" << Clr::RST;
}

void InventoryManager::do_list()
{
    std::cout << Clr::BOLD << Clr::CYN << "  [ ALL ITEMS ]\n" << Clr::RST;

    /* ── STL: vector to hold results ── */
    const int MAX = 1024;
    std::vector<Item> buf(MAX);
    int n = list_items(buf.data(), MAX);
    buf.resize(static_cast<size_t>(n));

    if (n == 0) {
        std::cout << Clr::DIM << "  (no active items in inventory)\n"
                  << Clr::RST;
        return;
    }

    /* ── STL: sort by ID ── */
    std::sort(buf.begin(), buf.end(),
              [](const Item &a, const Item &b){ return a.id < b.id; });

    print_divider();
    std::cout << "  "
              << Clr::BOLD
              << std::setw(5)  << "ID"
              << "  " << std::setw(20) << std::left  << "Name" << std::right
              << "  " << std::setw(8)  << "Qty"
              << "  " << std::setw(11) << "Price"
              << Clr::RST << '\n';
    print_divider();

    for (const auto &it : buf)
        print_item_row(it);

    print_divider();
    std::cout << Clr::DIM << "  " << n << " item(s) listed.\n" << Clr::RST;
}
