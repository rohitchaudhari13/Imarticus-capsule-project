/*
 * main.cpp  –  program entry point
 *
 * Creates an InventoryManager and starts the interactive loop.
 */

#include "InventoryManager.h"

int main()
{
    InventoryManager mgr;
    mgr.run();
    return 0;
}
